module.exports.help = function () {
    let a = 4
    console.log(`List of All the commands are ${a}
                1. View src -t: to view a directory as tree
                2. view src -f:  to view a directory as flat file
                3. untreefy src dest: to untreefy src files into directory
                4. treefy src dest: inverse of untreefy`)
}
