// let lib = require("./libModule");
// lib.myfn();
// lib.another();
// lib.private();
let uniqid = require("uniqid");
console.log(uniqid());
console.log(uniqid());
console.log(uniqid());