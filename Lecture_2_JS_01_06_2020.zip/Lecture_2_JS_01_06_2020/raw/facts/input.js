let input = process.argv.slice(2);
// console.log(Number(input[3]));